弥彦 V38 海景音效 Agent 实验 / 2026-11-09

1. original-sea.wav：原 V38 海浪试听。
2. daemon.wav / mcp.wav：两套开源工具在 REAPER 中执行同一方案后导出的结果，采样完全一致。
3. trial.rpp：可在 REAPER 打开的双轨实验工程，所需 sea-filtered.wav 已在包中。
4. cue.json：镜头需求；mixer-input-*.json：原 V38 混音器输入，记录本机路径。
5. verification.json：版本与实测结果；LICENSES.md：原工程来源署名。

本次方案：12.8–17.1 秒海景，原增益降低 3 dB，淡入 0.8 秒、淡出 0.65 秒，声像居中。试听文件保留实际混音电平。

脚本、安装与复现命令：
https://github.com/gitcyx93/niigata-mini-animations/tree/experiment/audio-agent-yahiko-sea/experiments/audio-agent

移动到另一台电脑后，重新生成 mixer-input 配置以更新素材与输出的绝对路径。
